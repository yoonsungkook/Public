package main

import (
    "sync"
    "time"
)

// In-memory 데이터 저장소
type Store struct {
    issues    map[uint]Issue
    users     map[uint]User
    nextIssueID uint
    mu        sync.RWMutex // 동시성 제어를 위한 뮤텍스
}

// Store 초기화 및 사용자 데이터 미리 채워넣기
func NewStore() *Store {
    s := &Store{
        issues:    make(map[uint]Issue),
        users:     make(map[uint]User),
        nextIssueID: 1,
    }
    // 미리 정의된 사용자 추가
    s.users[1] = User{ID: 1, Name: "김개발"}
    s.users[2] = User{ID: 2, Name: "이디자인"}
    s.users[3] = User{ID: 3, Name: "박기획"}
    return s
}

// 이슈 생성, 조회, 수정 등의 메서드 추가 (예: s.CreateIssue, s.GetIssue, s.UpdateIssue)
// ...