package main

import "time"

type User struct {
    ID   uint   `json:"id"`
    Name string `json:"name"`
}

type Issue struct {
    ID          uint      `json:"id"`
    Title       string    `json:"title"`
    Description string    `json:"description"`
    Status      string    `json:"status"`
    User        *User     `json:"user,omitempty"` // 담당자가 없을 수도 있으니 omitempty
    CreatedAt   time.Time `json:"createdAt"`
    UpdatedAt   time.Time `json:"updatedAt"`
}

// 이슈 상태 상수 정의
const (
    StatusPending    = "PENDING"
    StatusInProgress = "IN_PROGRESS"
    StatusCompleted  = "COMPLETED"
    StatusCancelled  = "CANCELLED"
)