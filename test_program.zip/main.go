package main

import (
    "log"
    "net/http"
    // "github.com/gorilla/mux" // gorilla/mux를 사용할 경우
)

var store *Store

func main() {
    store = NewStore() // 데이터 저장소 초기화

    // 라우터 설정
    // muxRouter := mux.NewRouter() // gorilla/mux를 사용할 경우
    // muxRouter.HandleFunc("/issue", CreateIssueHandler).Methods("POST")

    http.HandleFunc("/issue", CreateIssueHandler).Methods("POST") // Go 1.22 이상
    // Go 1.21 이하에서는 이렇게 직접 라우팅:
    // http.HandleFunc("/issue", func(w http.ResponseWriter, r *http.Request) {
    //     if r.Method == http.MethodPost {
    //         CreateIssueHandler(w, r)
    //     } else {
    //         http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
    //     }
    // })
    http.HandleFunc("/issues", GetIssuesHandler).Methods("GET")
    http.HandleFunc("/issue/", GetIssueDetailHandler).Methods("GET") // /issue/:id 패턴 처리
    http.HandleFunc("/issue/", UpdateIssueHandler).Methods("PATCH") // /issue/:id 패턴 처리

    log.Println("서버가 8080 포트에서 시작되었습니다...")
    log.Fatal(http.ListenAndServe(":8080", nil)) // nil 대신 muxRouter를 넣을 수 있음
}