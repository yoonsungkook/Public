1. 프로젝트 구조 및 환경설정
프로젝트 루트 폴더에 main.go, handlers.go, models.go, store.go, README.md 등을 나누어 구성
필요 패키지: net/http, github.com/gin-gonic/gin (추천), time, strconv
데이터는 임시로 서버 내 인메모리 저장 (slice 또는 map) 또는 간단한 DB 구조도 고려 가능
2. 데이터 모델
User와 Issue 구조체 정의
예제 내에서 제공된 구조체 사용
User는 3명 미리 초기화
Issue는 in-memory 저장 (또는 간단한 SQLite 활용 가능)

type User struct {
    ID   uint   `json:"id"`
    Name string `json:"name"`
}

type Issue struct {
    ID          uint      `json:"id"`
    Title       string    `json:"title"`
    Description string    `json:"description"`
    Status      string    `json:"status"`
    User        *User     `json:"user,omitempty"`
    CreatedAt   time.Time `json:"createdAt"`
    UpdatedAt   time.Time `json:"updatedAt"`
}

3. API 설계 핵심 포인트
모든 요청은 적절한 검증 단계 필요
상태 값은 PENDING, IN_PROGRESS, COMPLETED, CANCELLED 만 허용
담당자(userId) 유효성 검사, 존재 시 상태 변경, 부재시 PENDING
업데이트 시 필드별 조건 체크, 불변 조건도 유지
4. 핵심 기능별 구현 가이드
이슈 생성 POST /issue
요청 바디 검증
userId 존재 유무 체크
담당자 있으면 IN_PROGRESS, 없으면 PENDING
새 이슈 생성 후 반환
이슈 목록 조회 GET /issues
query param status 필터링 지원
전체 또는 특정 상태 리스트 반환
이슈 상세 조회 GET /issue/:id
존재하는 이슈 일치 여부 검증 후 반환
이슈 수정 PATCH /issue/:id
이슈 상태, 제목, 설명, 담당자 변경 가능
상태 조건에 따른 담당자 할당 변경 규칙 적용
COMPLETED, CANCELLED 이슈는 수정 불가
담당자-null시 상태 PENDING으로 변경
담당자 지정 시 상태는 IN_PROGRESS 또는 현재 상태 유지
에러 응답 구조
{
  "error": "에러 메시지",
  "code": 400
}

5. 테스트 방법 및 실행 안내 (README.md)
주요 실행 방법 (go run main.go)
API 테스트 예제(curl 또는 Postman)
초기 데이터 및 조건